## Usage
- run `make` (if on a 32-bit machine, need to change `ARCH` in top-level Makefile)
- `./main.py <colour>` to run

## Requirements
- requires `python2.7` command (does not work with python3), change in `main.py` if you need to
- tested on Ubuntu 16.04 LTS, with both gcc and clang, machine with 8GB of memory (uses around 2GB)
